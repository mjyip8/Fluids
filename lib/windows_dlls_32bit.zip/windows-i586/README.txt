This folder contains deprecated plain native libraries for platform windows-i586, please use the native JAR files in the jar folder.
